**State Store**
   
   它是系统的长期记忆和审计事实源。Run、Step、Trajectory Event、Model Call、Runtime Error、Checkpoint、Skill、Learning Candidate、Creative Evaluation 都落库。

   Skill 自进化主要发生在这一层：成功轨迹提炼 Skill Candidate，失败轨迹先进入 Learning Candidate，必须被后续同 Scope 成功恢复验证后，才可能参与 Skill 生成。

一、State Store 的框架定位
整个系统里 State Store 处在这里：
Execution Loop
  -> 产生 observation / action / result / verifier / error
      -> State Store 持久化

Batch / Training Runner
  -> 读取 runs / steps / events
      -> 失败分类
      -> Learning Candidate
      -> Skill Candidate
      -> Skill Promotion

Dashboard
  -> 读取 State Store
      -> 回放轨迹
      -> 查看错误
      -> 审核 Skill
      -> 查看评估结果

State Store 同时服务三类模块：
    执行恢复
    学习演化
    审计展示


二、State Store 存什么
原始执行事实
  runs
  steps
  trajectory_events
  model_calls
  runtime_errors
  checkpoints

长期学习状态
  task_memories
  learning_candidates
  skills

知识与评估
  knowledge_chunks
  creative_evaluations
  human_reviews

三、Run 是什么
Run 是一次完整任务尝试。
Run ID: run_001
Task: harvest_oak_log
Status: succeeded / failed / task_timeout / runtime_error
Started at: ...
Finished at: ...
Task Spec: 本次任务配置
resumed_from_checkpoint_id

Manifest 是任务文件
task_spec 是 Run 里的 JSON 配置
RunRecord 是数据库表

四、Step 是什么
Step 是一次 observe-action-result 循环。：它把一次任务拆成可回放的粒度。
Run 是任务级记录，Step 是决策级记录。每个 Step 保存 observation、action 和 action_result，方便重放 Agent 每一步为什么这么做。


五、Trajectory Event 是什么
Trajectory Event 是统一事件流，保存比 Step 更细的运行事实。它让 Dashboard 和后续学习模块可以从任意结论追溯到原始证据。
一次 Step 内部还会发生很多事件：
context_built
model_action
invalid_action
model_repair_attempt
knowledge_tool_call
action_result
verifier_result
runtime_error
checkpoint_saved
skill_lifecycle_event

六、Model Call 是什么
Model Call 记录模型调用本身。Model Call 独立落库是为了区分模型决策质量和环境执行质量，方便统计 token、成本、非法动作率和 repair 成功率。
模型有没有输出非法 JSON
token 用了多少
repair 前后的输出是什么
模型超时几次
某次错误是不是模型造成的

七、Runtime Error 是什么
Runtime Error 记录底层执行异常。Runtime Error 用来隔离基础设施故障，避免把 worker、server、RPC、model provider 的问题误写成 Agent 的游戏经验。

reset 失败
observe 失败
worker timeout
Mineflayer disconnected
RCON command failed
server crash

八、Checkpoint 是什么
Checkpoint 用于恢复执行状态。

它保存的不是完整 Minecraft 世界，而是 Harness 的运行状态：
next_step_index
task_spec
task_memory
previous_step
run_context
recent step summary
注意这个边界非常重要：
Checkpoint 恢复 Harness 状态
不等于恢复完整 Minecraft 世界状态

如果 Minecraft 世界被破坏，通常需要更高层的 reset 或 batch 重跑。
面试说法：
Checkpoint 解决的是 Harness 层的断点续跑，比如恢复 step index、任务记忆和压缩轨迹；它不是完整世界快照。真实环境一致性主要靠 reset、server 隔离和 wave 级别重跑保证。

九、Task Memory 是什么
Task Memory 是任务级记忆。

比如某次任务失败了：
Failed because zombie target was unreachable behind terrain.
下一次 retry 同一个任务时，可以把这条记忆注入 context：
Previous attempt failed because target was unreachable. Relocate before scanning again.


十、Learning Candidate 是什么
你前面已经问过，这里和 State Store 连起来讲。
Learning Candidate 是从失败 Run 中提取出的失败经验假设。
它会落库，因为它需要跨 Run 验证。

失败 Run
  -> 读取 runs / steps / trajectory_events
  -> 过滤 runtime_error / model_timeout 等噪声
  -> 找 gameplay failure
  -> 生成 Learning Candidate
  -> 后续同 Scope 成功 Run 验证它

失败不是直接进 Skill
失败先进入候选池
后续成功验证后才升级

十一、Skill 是什么
Skill 是长期可复用经验。
Skill Library 是 Agent 自进化的长期状态源。Skill 不是自动执行脚本，而是经过 Verifier 证据支持的参数化策略记忆。通常包括：

name
version
status
trigger
preconditions
scope
dependencies
strategy_summary
parameterized_plan
recovery_policy
source_run_id
source_step_range
raw_action_sequence
verifier_evidence
usage_count
last_verified
这个经验来自哪次 Run？
是哪几个 Step？
那次任务是否真的成功？
Verifier 证据是什么？
原始 action 序列是什么？

状态可能是：
draft
validated
staged
promoted
deprecated
模型使用 Skill 时，Context Manager 只注入摘要：
strategy_summary
parameterized_plan
recovery_policy


十二、Skill 自进化怎么发生在 State Store
完整闭环是：
Execution Loop 产生轨迹
  -> State Store 保存 Run/Step/Event
      -> Batch 结束后分析成功和失败 Run

成功 Run:
  -> 选择有效进展 Step
  -> 去掉无关探索
  -> 去掉绝对坐标
  -> 总结参数化策略
  -> 生成 Skill Candidate

失败 Run:
  -> 过滤基础设施噪声
  -> 生成 Learning Candidate
  -> 等后续同 Scope 成功 Run 验证
  -> 验证后参与 Skill Candidate

Skill Candidate:
  -> 相似度去重
  -> 版本化
  -> staged/promoted
  -> 写入 skills 表
也就是说：
State Store 不只是存结果
它提供 Skill 学习所需的证据链


十四、Creative Evaluation 和 Human Review
Programmatic task 可以用程序判断：
背包增加
击杀增加
目标状态完成
Creative task，比如建筑任务，没那么容易程序判断。
Creative Evaluation 可能包括：
录屏路径
关键帧数量
MineCLIP 分数
阈值
calibration_status
result

Human Review 包括：
人工审核结论
证据版本
reviewer decision
comments

MineCLIP 是辅助信号
Human Review 才能作为 creative task 更可信的最终判断


十五、哪些是表，哪些不是表
你可以这样记：
是表：
runs
steps
trajectory_events
model_calls
runtime_errors
checkpoints
task_memories
skills
learning_candidates
knowledge_chunks
creative_evaluations
human_reviews
不是单独表，通常是字段或文件：
task_spec
  -> runs.task_spec JSON 字段

task manifest
  -> tasks 目录下的 JSON/YAML 文件

action scope
  -> manifest/task_spec 里的 allowed_actions 字段

trace
  -> trace_id/span_id 字段，分布在 runs/steps/events/model_calls 等表

verifier
  -> manifest/task_spec 里的配置 + 代码里的 success_checker 实现

observation/action/action_result
  -> steps 表里的 JSON 字段，也会进入 trajectory_events



十六、State Store 的兜底设计
State Store 相关的兜底主要有几个。
第一，基础设施错误不进入 Skill 学习：
runtime_error
model_timeout
verification_inconclusive
这些不会直接生成 Learning Candidate。

第二，Skill 写入要幂等：
source_run_id 保证同一个 run 不重复生成同一批 skill

第三，Learning Candidate 要去重：
failure signature 防止重复创建同一种失败经验

第四，Skill Promotion 要并发控制：
数据库事务
行级锁
状态检查
避免多个 worker 同时把相似 skill 晋升。

第五，完整事实保留，模型上下文压缩：
数据库存完整轨迹
Prompt 只放压缩摘要
这让后续审计不会丢证据。


十七、面试怎么讲
你可以这样说：
State Store 是我设计的长期状态和审计事实源。Execution Loop 每一步都会把 observation、action、action result、model call、verifier result 和 runtime error 结构化记录下来，形成可回放的 trajectory。Run 和 Step 记录任务级和步骤级事实，Trajectory Event 保留更细的事件流，Model Call 单独记录模型输出和 token 使用，Runtime Error 用来隔离基础设施故障，Checkpoint 用来恢复 Harness 层执行状态。  
在 Skill 自进化上，State Store 提供证据基础：成功 Run 会经过有效进展步骤筛选，归纳为可参数化的 Skill Candidate；失败 Run 不会直接变成 Skill，而是先过滤 model timeout、worker error、verifier inconclusive 等基础设施噪声，只把有长期价值的 gameplay failure 归一化为 Learning Candidate。Candidate 必须在后续同 Scope 成功 Run 中被恢复策略验证，并通过 Verifier，才可能参与 Skill 生成。Skill 写入还会做相似度去重、版本管理、source_run_id 幂等和事务/行级锁并发控制，保证并行训练时 Skill Library 不被污染。

最关键的一句话：
State Store 的价值不是“把日志存起来”，而是把 Agent 的每一步环境交互变成可审计事实，再从这些事实中安全地产生长期技能记忆。