Learning Candidate：

适用范围：
采集类任务，尤其是采集方块后需要拿到掉落物的任务

观察到的失败：
Agent 挖掉了目标方块，但是背包数量没有增加

失败原因假设：
挖掉方块不等于已经获得物品，物品可能掉在地上，需要靠近拾取

建议恢复策略：
挖完方块后，不要马上提交任务
应该先扫描掉落物
如果看到 oak_log 掉落物，就走过去
等待几 tick
再查询背包
确认背包里有 oak_log 后再提交评估

证据：
来自 run_001
失败发生在 step 3 到 step 4
Verifier 结果是 inventory_delta 不满足


Skill 名称：
harvest_block_and_confirm_pickup

策略摘要：
采集方块时，挖掉方块后不要马上提交任务，需要确认掉落物被拾取到背包。

参数化步骤：
1. scan_blocks 找目标方块
2. move_to 靠近目标方块
3. dig_block_at 挖目标方块
4. scan_dropped_items 查找目标掉落物
5. move_to 靠近掉落物
6. wait_ticks 等待拾取
7. query_inventory 确认背包数量
8. submit_for_evaluation

恢复策略：
如果挖掘成功但背包没有增加，优先扫描附近掉落物，而不是重复挖方块。