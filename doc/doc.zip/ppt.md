ActionDecision:
一句话：HarnessAction 是“我要做什么”，ActionDecision 是“我为什么现在做这个、基于什么证据、需不需要查知识、要不要顺手记忆，然后才是我要做的动作”。
reasoning_summary：为什么选这个动作的简短说明。注意不是完整思维链，而是可审计摘要，比如“当前不知道背包里是否有木头，所以先查 inventory”。
evidence：这次决策依据了哪些可见证据。比如“上一步 scan_blocks 看到 oak_log”，“任务要求 craft planks”。它的作用是防止模型凭空拍脑袋，也方便后面 debug。

knowledge_need：模型声明“我是不是需要查知识”。例如不知道配方、方块名、Mineflayer 行为时，就把 needed=true，并且通常选择 retrieve_docs / get_recipe / resolve_terms 这类知识动作。

memory_update：顺手写入长期/本轮记忆的请求。比如扫描实体后发现某个实体不是目标，可以把这个事实记录下来，下一轮别重复犯错。










知识库 是一个受限、可审计、只读、本地优先的工具层。

输入：模型提出的知识查询 action
处理：去本地知识源里查
输出：结构化查询结果 action_result
用途：下一轮作为证据给模型看

最完整的流程是：
1. 模型看到任务和当前状态
   ↓
2. 模型发现自己缺知识
   比如不知道 wood 应该对应什么物品 ID
   ↓
3. 模型不直接猜，而是输出一个知识 action
   比如 resolve_terms / get_recipe / retrieve_docs
   ↓
4. Harness 发现这是知识 action
   所以不发给 Minecraft runtime
   ↓
5. KnowledgeToolDispatcher 调知识库查询
   ↓
6. 知识库返回结果
   ↓
7. Harness 把结果记录下来
   ↓
8. 下一轮模型看到查询结果
   ↓
9. 模型再选择真正的 Minecraft 动作


知识库对外只提供三种能力：
术语解析
配方查询
文档片段检索

resolve_terms：文本 → 标准 ID
get_recipe：物品 ID → 配方
retrieve_docs：问题 → 文档片段

resolve_terms：把任务或观察里的 Minecraft 词解析成规范 ID。这个词到底对应 Minecraft 里的哪个标准物品/方块/实体？
比如 “wood” 这种模糊词，查完可能得到 oak_log、oak_planks 这类 canonical id。
get_recipe：输入物品 ID，查某个物品的本地配方。这个东西怎么做？
比如要做 oak_button，它会返回输出数量、输入材料、工作站、是否需要燃料等。
retrieve_docs：查本地文档片段。输入是一个短 query：
当术语解析和配方还不够时，用它查机制说明，比如实体掉落、Mineflayer 行为、采集方式。

上游 1：本地知识源
minimal_minecraft_knowledge.json
processed minecraft knowledge，如果存在
硬编码补充 docs
SQL knowledge chunks，如果使用 DatabaseKnowledgeProvider

上游 2：ContextManager 把知识工具合同写进 system
告诉模型能用 resolve_terms/get_recipe/retrieve_docs
告诉模型不要联网、不要宽泛查询、一次最多一个知识工具

模型决策：
ActionDecision.knowledge_need 说明为什么要查
ActionDecision.action 选择具体知识 action

中游：ExecutionLoop 分流
如果 action.type 是知识动作，不进 Minecraft runtime
交给 KnowledgeToolDispatcher

中游：KnowledgeToolDispatcher 查询
resolve_terms → provider.resolve_terms
get_recipe → provider.get_recipe
retrieve_docs → provider.retrieve_docs

下游 1：返回 action_result
作为本轮动作结果记录

下游 2：写入 run_context.knowledge
用于后续上下文，可缓存、可压缩、可重新查询

下游 3：压缩进 compact_evidence.previous_step
下一轮模型可以把它当最高优先级的上一轮证据

下游 4：模型下一轮基于知识结果选择世界动作
比如 move_to、scan_blocks、dig_block_at、process_item、submit_for_evaluation



知识库来源：

默认知识库的数据来源”开始。先给框架，后面都按这个框架讲：
知识库来源
  ↓
StaticKnowledgeProvider 加载并合并
  ↓
提供 3 个查询能力
  ↓
KnowledgeToolDispatcher 包装成工具结果
  ↓
结果回到下一轮上下文

来源详情：

默认知识库不是一个数据库服务，而是几个本地文件 + 一点代码内置文档合起来。
先加载 minimal，再加载 generated；
如果同一个 ID 重复，手写的 minimal 会覆盖 generated。
1. knowledge/raw/minimal_minecraft_knowledge.json   手写的基础知识库，启动时最小可用知识
    terms：术语表，比如 oak_log、stick、zombie
    recipes：基础配方，比如 oak_log → oak_planks
    documents：本地说明片段，比如 Mineflayer 操作说明

    {
        "canonical_id": "oak_log",
        "kind": "block",
        "aliases": ["log", "logs", "wood"],
        "description": "A common tree block harvested from oak trees."
    }
2. knowledge/processed/minecraft_1_20_1_knowledge.json
    minecraft-data 是 Mineflayer 生态里常用的 Minecraft 数据包，里面有物品、方块、实体、配方等版本数据。

3. OBTAINING_DOCUMENTS
    补上一些高频任务知识，尤其是“某个物品怎么获得”这种经验说明。
    Feather 通常来自 chicken/parrot 掉落
    Pig 会掉 porkchop
    wood/log/planks 默认可以映射到 oak 系列
    动物掉落任务应该先找对应实体


总体老说：把 minecraft-data 转成 agent 好用的知识格式；
再加上手写补丁；
再通过 resolve_terms/get_recipe/retrieve_docs 暴露给模型。

清晰的归类：
minecraft-data 提供“有哪些东西”；
项目手写补丁决定“任务里的模糊词默认选哪个东西”。
resolve_terms 查什么？
- minimal 里手写的 terms aliases
- processed 里 minecraft-data 生成的 terms aliases
- FAMILY_CANONICAL_ALIASES 手写补丁映射

get_recipe 查什么？
- minimal 里手写的基础 recipes
- processed 里 minecraft-data 生成的 recipes

retrieve_docs 查什么？
- minimal 里手写 documents
- processed 里生成 documents
- OBTAINING_DOCUMENTS 手写补充 documents


为什么还需要人补充：
我们主要补的是 `minimal_minecraft_knowledge.json` 和代码里的少量手写规则，它们不是为了替代 `minecraft-data`，而是为了把“完整但机械的版本数据”变成“agent 能直接执行的任务知识”：`minecraft-data` 知道游戏里有很多种 log、planks、button 和大量配方，但任务常常只写 `wood`、`planks`、`wooden button` 这种模糊词，agent 执行动作时又必须传具体 ID，所以我们手写补充常见别名、默认映射、基础采集/合成链和获得方式说明，让模型少猜、能落到稳定可执行的目标上。

例子可以这样讲：

```text
任务写的是 “craft a wooden button”，minecraft-data 里有 oak_button、birch_button、spruce_button 等很多按钮，但 agent 不能对 runtime 说“做一个 wooden button”，它必须选择一个具体物品 ID；所以项目手写规则把 wooden button/button 默认映射成 oak_button，再通过配方知识知道 oak_button 需要 oak_planks，这样模型后续才能去查背包、采 oak_log、合成 oak_planks，最后做 oak_button。
```